# Smart Task Summarizer + Tagger

## Overview

This is a Python Flask web application with pure HTML/CSS frontend that processes unstructured task descriptions using Google's Gemini API to transform them into organized, prioritized tasks. The application provides an AI-powered solution for busy project managers to automatically summarize, tag, and prioritize messy task descriptions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a simple and clean architecture:

- **Frontend**: Pure HTML5/CSS3 with vanilla JavaScript
- **Backend**: Python Flask with RESTful API endpoints
- **Storage**: In-memory Python data structures (for simplicity)
- **AI Integration**: Google Gemini 2.0-flash-exp for task processing
- **UI Framework**: Custom CSS with responsive design
- **State Management**: Native JavaScript with fetch API

## Key Components

### Frontend Architecture
- **Pure HTML5**: Semantic markup with accessibility considerations
- **Custom CSS**: Responsive design with CSS Grid and Flexbox
- **Vanilla JavaScript**: Modern ES6+ features for DOM manipulation and API calls
- **Font Awesome**: Icon library for visual elements
- **Mobile-First**: Responsive design that works on all devices

### Backend Architecture
- **Flask Framework**: Lightweight Python web framework
- **RESTful API**: Clean endpoint design for task operations
- **In-Memory Storage**: Simple Python list and dictionary storage
- **Gemini AI Service**: Google's latest Gemini model integration
- **Error Handling**: Comprehensive try-catch blocks with user-friendly messages
- **CORS Support**: Cross-origin resource sharing for development

### Data Model
- **Task Structure**: Dictionary with id, rawText, summary, tags, priority, timeEstimate, createdAt
- **Storage Format**: Python list of dictionaries for easy manipulation
- **Statistics**: Real-time calculation of priority distribution and time estimates

## Data Flow

1. **Task Input**: Users enter raw, unstructured task descriptions
2. **AI Processing**: Tasks are sent to OpenAI GPT-4o for analysis and structuring
3. **Data Storage**: Processed tasks are stored in PostgreSQL database
4. **Real-time Updates**: Frontend uses TanStack Query for automatic data synchronization
5. **Export Functionality**: Tasks can be exported as CSV files

### Task Processing Pipeline
- Clear existing tasks before processing new batch
- Send raw tasks to Gemini with configurable parameters (priority scale, tag limits, time estimates)
- Parse AI response using JSON schema validation
- Store processed tasks in memory
- Return formatted results to frontend with real-time statistics

## External Dependencies

### Core Dependencies
- **Google Gemini API**: Latest Gemini 2.0-flash-exp model for intelligent task processing
- **Flask**: Lightweight and flexible Python web framework
- **Font Awesome**: Comprehensive icon library for UI elements

### Development Tools
- **Python 3.11**: Modern Python runtime with type hints
- **Flask Development Server**: Built-in server with hot reload
- **Google GenerativeAI**: Official Python SDK for Gemini integration

## Deployment Strategy

### Development Environment
- **Frontend**: Static HTML/CSS/JS served by Flask
- **Backend**: Flask development server with debug mode
- **Storage**: In-memory Python data structures

### Production Deployment
- **Frontend**: Static assets served by Flask
- **Backend**: Flask application with WSGI server
- **Scaling**: Stateless design allows easy horizontal scaling

### Environment Configuration
- **AI Service**: Gemini API key configuration via environment variables
- **Port Configuration**: Flexible port assignment (currently 5001)
- **Debug Mode**: Enabled for development with hot reload

### Key Architectural Decisions

1. **Simplicity First**: Pure HTML/CSS/JS frontend eliminates build complexity and dependencies
2. **Python Backend**: Flask provides lightweight, readable, and maintainable server code
3. **In-Memory Storage**: Eliminates database complexity while maintaining full functionality
4. **Gemini Integration**: Google's latest AI model provides superior task processing capabilities
5. **Mobile-Responsive**: CSS Grid and Flexbox ensure optimal experience across all devices
6. **No-Build Deployment**: Direct file serving reduces deployment complexity and startup time

## Recent Changes (July 30, 2025)

✓ **Complete Architecture Migration**: Successfully migrated from Node.js/React to Python Flask with pure HTML/CSS
✓ **Gemini API Integration**: Replaced OpenAI with Google's Gemini 2.0-flash-exp model
✓ **Simplified Frontend**: Rebuilt UI using vanilla JavaScript, HTML5, and custom CSS
✓ **Flask Backend**: Created comprehensive Python Flask API with all original functionality
✓ **Responsive Design**: Implemented mobile-first CSS with professional styling
✓ **In-Memory Storage**: Simplified data persistence using Python data structures
✓ **Error Handling**: Added robust error handling and user feedback systems